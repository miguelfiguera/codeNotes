# Notas y estudio sobre RSPEC para Rails.

Hola! Mi nombre es miguel figuera, y siempre he sido bastante torpe en el tema de hacer testings para mi codigo, en algun punto falle terriblemente una entrevista porque (aparte de los nervios) nunca ejercite lo suficiente mis capacidades para testear codigo. Independientemente de la herramienta, es crucial tener la capacidad de manejar el testing del codigo que hacemos. Asi sea simplemente por conocimiento general.

Esta en español porque escribiendo en español memorizo mejor. Es mi lengua materna, pero esta escrito de forma que cualquiera pueda ponerlo en la ia y que se lo traduzcan.

Sin embargo, dado el hecho de que para un backend es fundamental conocer las herramientas y como testearlas, pues decidí compartir mis notas y mis estudios sobre como testear.

Seria genial que mas personas agreguen las suyas, puesto que yo me centraré principalmente en Rails (al menos en este punto) y tengo claro que Rails no es de uso tan común como otros frameworks de capacidad similar como nestjs, express, django, etc...

De todos modos lo comparto esperando que colabore con el crecimiento de mis colegas.

Att: Miguel F. Quintero.

Rawrf.

## Orden:

1. tddBasics.md
2. rspecBasics.md
3. rspec-mocks.md
4. shouldaMatchers.md
5. factories.md
6. ejercicios.md
7. ejerciciosResueltos.md (deberia ser tu propia copia).

---
